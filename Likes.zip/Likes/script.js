
var likes = 9;
function increase(){
    var likesElement = document.querySelector(".likes")
    likes++;
    console.log(likes)
    likesElement.innerText = likes + " like(s)";
}

var likes1 = 12;
function increase1(){
    var likesElement = document.querySelector(".likes1")
    likes1++;
    console.log(likes1)
    likesElement.innerText = likes1 + " like(s)";
}

var likes2 = 9;
function increase2(){
    var likesElement = document.querySelector(".likes2")
    likes2++;
    console.log(likes2)
    likesElement.innerText = likes2 + " like(s)";
}